# Mac下不能使用
# from scrapy import cmdline
# cmdline.execute("scrapy crawl JDSpider".split())